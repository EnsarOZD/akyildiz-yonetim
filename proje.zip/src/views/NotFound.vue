<template>
  <div class="flex flex-col items-center justify-center min-h-screen bg-base-200">
    <div class="text-center">
      <h1 class="text-9xl font-black text-primary">404</h1>
      <p class="text-2xl md:text-3xl font-bold text-base-content mt-4">Sayfa Bulunamadı</p>
      <p class="text-base-content/70 mt-4 mb-8">Üzgünüz, aradığınız sayfayı bulamadık.</p>
      <router-link to="/" class="btn btn-primary">Ana Sayfaya Dön</router-link>
    </div>
  </div>
</template>

<script setup>
</script> 